import time
import numpy as np
import pandas as pd

# use the local binfilepy
from os import path
import sys
#sys.path.append(path.abspath('/Users/yp/Google Drive/think for mac/ucla_health/binfilepy_git'))
#sys.path.append(path.abspath('/home2/yup1/binfilepy_git'))
#from binfilepy import binfile

from deidentify.deidentifier import Deidentifier
from to_csv.single_file_processor import SingleFilePorcessor

class ProcessorAdibin(SingleFilePorcessor):

    def __init__(self, dob, mask, binfilepy_path, debug_yn=True):
        super().__init__(dob, mask, debug_yn)
        self.binfilepy_path = binfilepy_path

    def create_dataframe(self, input_file):
        start_time = time.time()

        sys.path.append(path.abspath(self.binfilepy_path))
        from binfilepy import binfile

        with binfile.BinFile(input_file, "r") as f:
            # You must read header first before you can read channel deidentify
            f.readHeader()
            # I want to read the entire file
            data = f.readChannelData(offset=0, length=0, useSecForOffset=False, useSecForLength=False)

        begin_time = pd.to_datetime(str(f.header.Month) + '/' + str(f.header.Day) + '/' + str(f.header.Year) + ' ' + str(f.header.Hour) + ':' + str(f.header.Minute) + ':' + str(f.header.Second))
        sf = 300  # this is the max sampling rate for UCI that all the files are upsampled to

        if self.debug_yn:
            print('Dataformat: ', f.header.DataFormat)
            print('Seconds per tick: ', f.header.secsPerTick)  # sampling rate 300 Hz
            print('begin_time: ', begin_time)
            print(f.header.__dict__)

        for fii in np.arange(len(f.channels)):
            if self.debug_yn:
                print('Title: ', f.channels[fii].Title, ', Units: ', f.channels[fii].Units, ', Scale: ', f.channels[fii].scale, ', Offset: ', f.channels[fii].offset)
            if fii == 0:
                wave = pd.DataFrame(data[fii], columns=[f.channels[fii].Title])
            else:
                wave[f.channels[fii].Title] = data[fii]
            '''
            if f.channels[fii].Title in ['GE_ART', 'INVP1']:
                wave.loc[wave[f.channels[fii].Title] < 0, f.channels[fii].Title] = 0.
            if f.channels[fii].Title in ['GE_ECG', 'ECG', 'PLETH']:
                wave.loc[wave[f.channels[fii].Title] == -1.700000e+308, f.channels[fii].Title] = 0.
            '''

        wave['timestamp'] = begin_time + pd.to_timedelta(wave.index * f.header.secsPerTick, unit='s') #- pd.Timedelta('8H')
        if self.debug_yn:
            print("=========original wave dataframe ============", wave.head())

        #'''
        wave['Sequence'] = [Deidentifier.get_sequence(str(d.date()), self.dob, self.mask) for d in wave['timestamp']]
        wave['CollectionTime'] = [d.time() for d in wave['timestamp']]
        #wave = wave.set_index('timestamp')
        del wave['timestamp']
        cols = wave.columns.tolist()
        cols = cols[-2:] + cols[:-2]
        wave = wave[cols]
        if self.debug_yn:
            print("!!!!!!!!!!deidentified wave dataframe !!!!!!!!!!!", wave.head())
        #'''
        elapsed_time = time.time() - start_time
        if self.debug_yn:
            print("ProcessorAdibin.create_dataframe elapsed_time: ", elapsed_time)

        return wave
