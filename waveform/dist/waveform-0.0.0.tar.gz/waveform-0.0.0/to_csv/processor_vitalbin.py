'''
Please see the below code to read .Vital file. This can be used to convert .vital file to csv.
https://github.com/hulab-ucsf/vitalfilepy/blob/master/tests/test_vitalfilepy.py
'''

import os
import re
import time
import pandas as pd

from vitalfilepy import VitalFile
from deidentify.deidentifier import Deidentifier
from to_csv.single_file_processor import SingleFilePorcessor



class ProcessorVitalbin(SingleFilePorcessor):
    def create_dataframe(self, input_file):
        start_time = time.time()

        #print("!!!!!!!!!!!!!!!!!!!", input_file, os.path.basename(input_file).split('.')[0].split('_')[1])
        #begin_time_str = os.path.basename(input_file).split('.')[0].split('_')[1]

        def get_timestamp(filename):
            matched = re.search('_\d{14}_', filename)
            if matched != None:
                return matched.group()[1:-1]

        begin_time_str = get_timestamp(os.path.basename(input_file))
        begin_time = pd.to_datetime(begin_time_str[0:4] + '/' + begin_time_str[4:6] + '/' + begin_time_str[6:8] + ' ' + begin_time_str[8:10] + ':' + begin_time_str[10:12] + ':' + begin_time_str[12:14])

        data = []
        with VitalFile(input_file, "r") as f:
            f.readHeader()
            # print(f.header.__dict__)
            # {'Label': 'ECT', 'Uom': '', 'Unit': '6N', 'Bed': 'W664', 'Year': 0, 'Month': 0, 'Day': 0, 'Hour': 0, 'Minute': 0, 'Second': 0.0}
            line = f.readVitalData()
            try:
                while True:
                    data.append(f.readVitalData())
            except:
                    pass

        if self.debug_yn:
            print("vital len(deidentify): ", len(data))

        vital = pd.DataFrame(data, columns =['value','offset','low','high'])

        secsPerTick = 1
        vital['timestamp'] = begin_time + pd.to_timedelta(vital.index * secsPerTick, unit='s')

        vital['Sequence'] = [Deidentifier.get_sequence(str(d.date()), self.dob, self.mask) for d in vital['timestamp']]
        vital['CollectionTime'] = [d.time() for d in vital['timestamp']]
        #wave = wave.set_index('timestamp')
        del vital['timestamp']
        cols = vital.columns.tolist()
        cols = cols[-2:] + cols[:-2]
        vital = vital[cols]

        elapsed_time = time.time() - start_time
        if self.debug_yn:
            print("ProcessorVitalbin.create_dataframe elapsed_time: ", elapsed_time)

        return vital



