import unittest

from to_csv.single_file_processor import SingleFilePorcessor

class TestSingleFilePorcessor(unittest.TestCase):
    def test_deidentified_filename(self):
        print("Starting unittest")

        filename1 = "_20181016185515_0000_RR.vital"
        df1 = SingleFilePorcessor("dob","mask").deidentified_filename(filename=filename1)
        expected_df1 = "_185515_0000_RR.vital"
        self.assertEqual(df1, expected_df1)

        filename2 = "_20190718144723_20190718144727.adibin"
        df2 = SingleFilePorcessor("dob","mask").deidentified_filename(filename=filename2)
        expected_df2 = "_144723_144727.adibin"
        self.assertEqual(df2, expected_df2)

if __name__ == '__main__':
    unittest.main()
